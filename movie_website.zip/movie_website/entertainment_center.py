import fresh_tomatoes
import media

hacksaw_ridge = media.Movie("Hacksaw rige",
                        "The film adapted from the World War II Lance Corporal Desmond Dawes tells the military real experience,  and legend in the battle  rescued 75 comrades",
                        "http://img31.mtime.cn/pi/2016/09/08/152239.84514110_1000X1000.jpg",
                        "http://player.youku.com/player.php/sid/XMTc2ODQzNDM4OA==/v.swf")
#print(toy_story.storyline)
#hacksaw_ridge.show_trailer()
beauty_beast = media.Movie("Beauty_beast",
                        "The film depicts a prince into the beast,  his father and girl Bellefinally successfully release the magic beast Belle life together in the story ",
                        "http://img5.mtime.cn/pi/2016/11/03/093101.34484871_1000X1000.jpg",
                        "http://player.youku.com/player.php/sid/XMjUyMzQ3MDk2NA==/v.swf")
#print(avatar.storyline)
#beauty_beast.show_trailer()

avngers_grimm = media.Movie("Avengers grimm",
                        "When the dwarf destroyed the magic mirror, and fled to the real world, the former four princesses were sucked through the portal ",
                        "http://img31.mtime.cn/pi/2013/03/27/151700.86818786_1000X1000.jpg",
                        "http://player.youku.com/player.php/sid/XMTU0ODk0ODA2MA==/v.swf")
#avngers_grimm.show_trailer()

movies = [hacksaw_ridge,beauty_beast,avngers_grimm]
fresh_tomatoes.open_movies_page(movies)


